function contac(){
    alert("Contact us at 555-5555")
}

var count=0
function buy(){
    count++;
    var element = document.querySelector("#number");
    console.log(element);
    element.innerText=count;
}

function select(value){
    var element1 = document.querySelector("#text")
    if(value =="P"){
        element1.innerText="Price"
    }
    else
         element1.innerText="Best Selling"
}